from django.contrib import admin
from .models import TimeEntry

admin.site.register(TimeEntry)